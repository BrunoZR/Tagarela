﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Tagarela.Migrations
{
    public partial class NovaImigracao : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<long>(
                name: "Curtidas",
                table: "Mensagens",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0L);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Curtidas",
                table: "Mensagens");
        }
    }
}
