﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Tagarela.Migrations
{
    public partial class EtapaRetagarelar : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "RetagareladaId",
                table: "Mensagens",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Mensagens_RetagareladaId",
                table: "Mensagens",
                column: "RetagareladaId");

            migrationBuilder.AddForeignKey(
                name: "FK_Mensagens_Mensagens_RetagareladaId",
                table: "Mensagens",
                column: "RetagareladaId",
                principalTable: "Mensagens",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Mensagens_Mensagens_RetagareladaId",
                table: "Mensagens");

            migrationBuilder.DropIndex(
                name: "IX_Mensagens_RetagareladaId",
                table: "Mensagens");

            migrationBuilder.DropColumn(
                name: "RetagareladaId",
                table: "Mensagens");
        }
    }
}
